<!--if there is anyone who help me fix this footer, i will buy him/her a coffee.by newnius -->
<footer class="container" >
  <div class="footer">
    <ul class="breadcrumb">
    <li>&copy;2015&nbsp;<a href="http://blog.newnius.com" target="_blank">Newnius</a></li>
    <li><a href="http://quickauth.newnius.com">QuickAuth</a></li>
    <li><a href="#">Terms</a></li>
    <li><a href="help.php#qid-5">Privacy</a></li>
    <li><a href="help.php#qid-999">Contact</a></li>
    <li><a href="help.php?footer">Help</a></li>
    <li><a href="help.php#qid-1">About</a></li>
    <li><a href="#">Links</a></li>
    </ul>
  </div>
</footer>










